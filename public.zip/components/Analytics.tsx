'use client';

import { usePathname, useSearchParams } from 'next/navigation';
import { useEffect, Suspense } from 'react';

function AnalyticsInner() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    if (pathname) {
      const url = pathname + (searchParams?.toString() ? `?${searchParams.toString()}` : '');
      console.log('Page view:', url);

      // Google Analytics page view
      if (typeof window !== 'undefined' && (window as any).gtag) {
        (window as any).gtag('config', process.env.NEXT_PUBLIC_GA_ID || '', {
          page_path: pathname,
        });
      }

      // Simulated beacon as fallback when no analytics ID configured
      if (!process.env.NEXT_PUBLIC_GA_ID) {
        try {
          navigator.sendBeacon('/api/analytics', JSON.stringify({
            type: 'pageview',
            url,
            timestamp: Date.now(),
          }));
        } catch {
          // Beacon API not available — silently skip
        }
      }
    }
  }, [pathname, searchParams]);

  return null;
}

export default function Analytics() {
  return (
    <Suspense fallback={null}>
      <AnalyticsInner />
    </Suspense>
  );
}