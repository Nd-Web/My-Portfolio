import SkipToContent from '@/components/SkipToContent';
import ClientLayout from '@/components/ClientLayout';

export default function Home() {
  return (
    <>
      <SkipToContent />
      <ClientLayout />
    </>
  );
}